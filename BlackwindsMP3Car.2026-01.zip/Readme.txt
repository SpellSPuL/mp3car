Blackwind's Mp3 Car Software
(c)1998-2026 Christopher Evans

Current Site -
novaroma.io/archive.html

Archived Site -
https://web.archive.org/web/20030307143237/http://users.rcn.com/caevans/mp3car/indexcss.html

This software is licensed under the Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International License (CC BY-NC-ND 4.0).

You may copy and redistribute this software in any medium or format for non-commercial purposes only, provided that you give appropriate credit, provide a link to the license, and indicate if any license notice was changed. You may not use the software for commercial purposes, and if you modify, transform, or build upon it, you may not distribute the modified material.

--------------------------------

Say The Time - Have the computer tell you the time

CD Operations - Open, close or play optical disks.

Winamp IR remote - Packard Bell Fast Media Remote control for Winamp

Keypad Controller - Plug-in to control Winamp

LED array VU meter - Winamp plug-in that drives a LED VU meter

m3uf - Program that numbers and formats m3u playlists for printing.

LEDographer - "scripting" utility to control the LED array.

DOS Batch Helpers - Small programs that drive a Hitachi LCD under DOS.


